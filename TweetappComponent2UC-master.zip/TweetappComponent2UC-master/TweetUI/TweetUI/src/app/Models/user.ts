export class User {
    public userId:number;
    public firstName: string;
    public lastName:string;
    public username:string;
    public emailId:string;
    public password:string;
    public contactNumber:string;
    public imageName:string;
}
