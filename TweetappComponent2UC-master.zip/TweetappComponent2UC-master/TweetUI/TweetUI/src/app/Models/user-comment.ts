export class UserComment {
    public tweetid:number;
    public username: string;
    public comments: string;
    public date:Date;
    public imageName:string;
}
