export class RegisteredUser {
    public firstname: string;
    public lastname:string;
    public username: string;
    public imagename:string;
}
