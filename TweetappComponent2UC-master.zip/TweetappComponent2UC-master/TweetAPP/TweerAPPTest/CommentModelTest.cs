﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TweetAPP.Models;
using Xunit;

namespace TweerAPPTest
{
    public class CommentModelTest
    {
        [Fact]  
        public void CommentTest()
        {
            Comment obj = new Comment
            {
                Comments = "hello",
                Date = new DateTime(),
                Id=1,
                TweetId=1,
                Username="test",
            };
            Assert.NotNull(obj.Comments);
            Assert.IsType<DateTime>(obj.Date);
            Assert.IsType<int>(obj.Id);
            Assert.NotNull(obj.Username);
            Assert.IsType<int>(obj.TweetId);    
        }
    }

}
