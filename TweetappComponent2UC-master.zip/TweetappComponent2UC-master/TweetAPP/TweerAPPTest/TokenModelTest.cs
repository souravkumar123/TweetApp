﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TweetAPP.Models;
using Xunit;

namespace TweerAPPTest
{
    public class TokenModelTest
    {
        [Fact]
        public void TokenModel()
        {
            Token obj = new Token
            {
                Message ="hello",
                Tokens="asdsa",
                UserId=1,
                Username="test",
            };
            Assert.Equal("hello", obj.Message);
            Assert.IsType<string>(obj.Tokens);
            Assert.IsType<string>(obj.Tokens);
            Assert.IsType<int>(obj.UserId);
            Assert.IsType<string>(obj.Username);    
        }

        [Fact]
        public void TweetTest()
        {
            Tweet obj = new Tweet
            {
                FirstName = "amlesh",
                LastName = "roy",
                Id = 1,
                Likes = 1,
                TweetDate = new DateTime(),
                Tweets = "hi",
                Comments = new List<Comment> { new Comment { Id = 1, } },
                UserId = 1,
                Username = "test",
            };
            Assert.IsType<string> (obj.Tweets);
            //Assert.IsType<int>(obj.Comments);
            Assert.IsType<int>(obj.UserId);
            Assert.IsType<int> (obj.Id);
            Assert.IsType<string>(obj.Username);
            Assert.IsType<DateTime>(obj.TweetDate);
            Assert.IsType<int>(obj.Likes);
        }
    }

}
